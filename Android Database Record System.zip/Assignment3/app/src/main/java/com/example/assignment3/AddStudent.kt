package com.example.assignment3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.annotation.MainThread

class AddStudent : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_student)

        var regno: EditText = findViewById(R.id.stdReg)
        var name: EditText = findViewById(R.id.stdName)
        var cgpa: EditText = findViewById(R.id.stdCgpa)
        var age: EditText = findViewById(R.id.stdAge)
        var subjects: EditText = findViewById(R.id.stdSub)
        var address: EditText = findViewById(R.id.stdAddr)

        var save: Button = findViewById(R.id.button)

        save.setOnClickListener({
            // data will be saved here
            // reading data from interface
            var strReg = regno.text.toString()
            var strName = name.text.toString()
            var strCgpa = cgpa.text.toString()
            var strAge = age.text.toString()
            var strSubjects = subjects.text.toString()
            var strAddress = address.text.toString()
            if (strReg.isNotEmpty() && strName.isNotEmpty() && strCgpa.isNotEmpty() && strAge.isNotEmpty() && strSubjects.isNotEmpty() && strAddress.isNotEmpty()) {
                var myDB: MyDatabaseClass = MyDatabaseClass(this)
                myDB.insertRecord(strReg, strName, strCgpa.toFloat(), strAge.toInt(), strSubjects.toInt(), strAddress)
            }
            else
            {
                Toast.makeText(MainActivity@ this, "Please Give All the Information", Toast.LENGTH_SHORT)
            }


        })

    }
}