package com.example.assignment3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var Add:Button = findViewById(R.id.addSt)
        var Search:Button = findViewById(R.id.searchSt)
        var Delete:Button = findViewById(R.id.deleteSt)
        var Display:Button = findViewById(R.id.displaySt)

        Add.setOnClickListener({
            startActivity(Intent(this, AddStudent::class.java))
        })

        Search.setOnClickListener({
            startActivity(Intent(this, SearchStudent::class.java))
        })

        Delete.setOnClickListener({
            startActivity(Intent(this, DeleteStudent::class.java))
        })

        Display.setOnClickListener({
            startActivity(Intent(this, DisplayStudent::class.java))
        })
    }
}