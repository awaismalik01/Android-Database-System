package com.example.assignment3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class SearchStudent : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_student)

        var pat:EditText = findViewById(R.id.patSearch)
        var SearchButton:Button = findViewById(R.id.Search)
        var db = MyDatabaseClass(this)
        var Data = listOf<String>()
        var myListView : ListView = findViewById(R.id.RecordList)
        SearchButton.setOnClickListener({
            var DV = pat.text.toString()

            if(DV.isNotEmpty()) {

                Data = db.getPatternData(DV)

                var myAdapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Data)
                myListView.adapter = myAdapter
            }
        })

        myListView.setOnItemClickListener{
            parent, view, position, id ->

            Toast.makeText(baseContext, "You have clicked an record: "+  Data[position], Toast.LENGTH_SHORT).show()

        }
    }
}