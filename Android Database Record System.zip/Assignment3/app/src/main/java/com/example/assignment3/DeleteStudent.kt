package com.example.assignment3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class DeleteStudent : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_delete_student)

        var pat: EditText = findViewById(R.id.patDelete)
        var DeleteButton: Button = findViewById(R.id.Delete)
        var db = MyDatabaseClass(this)
        DeleteButton.setOnClickListener({
            db.deleteData(pat.text.toString())
        })

    }
}