package com.example.assignment3

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.CursorAdapter
import android.widget.Toast

class MyDatabaseClass(var view: Context) : SQLiteOpenHelper(view, "MyDatabase.db", null, 1) {
    val tableName = "Student"
    override fun onCreate(db: SQLiteDatabase?) {
        var tableQuery: String =
            "CREATE TABLE $tableName(REGNO VARCHAR(20) primary key, NAME CHAR(32), CGPA FLOAT, AGE INT, SUBJECTS INT, ADDRESS varchar(200))"

        //"CREATE TABLE $tableName(ID Integer primary key autoincrement , REGNO VARCHAR(20), NAME CHAR(32), EMAIL VARCHAR(100), CGPA FLOAT )"
        db?.execSQL(tableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE if exists $tableName")
        onCreate(db)
    }

    //myDB.insertRecord(strReg, strName, strCgpa.toFloat(), strAge.toInt(), strSubjects.toInt(), strAddress)
    fun insertRecord(parReg: String, parName: String, parCGPA: Float, parAge: Int, parSubjects: Int, parAddress: String) {

        val alertMessage: AlertDialog.Builder = AlertDialog.Builder(MainActivity@ view)
        alertMessage.setTitle("Do you want to Save Record!!!")
        alertMessage.setMessage("Reg: ${parReg.toUpperCase()} \nName: $parName \nCGPA: $parCGPA \nAge: $parAge \nSubjects: $parSubjects \nAddress: $parAddress\n")

        alertMessage.setPositiveButton("Save", { a, b ->
            var db = writableDatabase
            var contValue: ContentValues = ContentValues()

            contValue.put("REGNO", parReg)
            contValue.put("NAME", parName)
            contValue.put("CGPA", parCGPA)
            contValue.put("AGE", parAge)
            contValue.put("SUBJECTS", parSubjects)
            contValue.put("ADDRESS", parAddress)
            var insertResult = db.insert(tableName, null, contValue)

            if (insertResult > 0)
                Toast.makeText(view, "Record is inserted", Toast.LENGTH_SHORT).show()
            else
                Toast.makeText(view, "Duplication, Record not saved... ", Toast.LENGTH_SHORT).show()

        })

        alertMessage.setNeutralButton("Cancel", { id, d ->
            //Toast.makeText(MainActivity@ this, "You pressed done button", Toast.LENGTH_SHORT).show()
        })

        alertMessage.create()
        alertMessage.show()
    }


    fun ReadAllRecords():List<String> {

        var db = readableDatabase
        var readQuery = "Select * from $tableName"
        var allData: Cursor = db.rawQuery(readQuery, null)
        var size = allData.count

        var x = 0
        var Data = listOf<String>()
        allData.moveToFirst()
        var completeData = ""
        while (x < size) {
            var col1 = allData.getString(allData.getColumnIndex("REGNO"))
            var col2 = allData.getString(allData.getColumnIndex("NAME"))
            var col3 = allData.getFloat(allData.getColumnIndex("CGPA"))
            var col4 = allData.getInt(allData.getColumnIndex("AGE"))
            var col5 = allData.getInt(allData.getColumnIndex("SUBJECTS"))
            var col6 = allData.getString(allData.getColumnIndex("ADDRESS"))

            completeData = "Record No. ${x + 1} \nRegNo: $col1 \nName: $col2 \n" +
                    "CGPA: $col3\n" +
                    "Age: $col4\n" +
                    "Subjects: $col5\n" +
                    "Address: $col6"
            Data += completeData

            allData.moveToNext()
            x++
        }

        return Data
    }

    fun deleteData(pattern: String)
    {
        var db = readableDatabase
        var readQuery = "Select * from $tableName where UPPER(REGNO) = UPPER('$pattern')"
        var allData: Cursor = db.rawQuery(readQuery, null)
        var size = allData.count

        var x = 0
        var Data = listOf<String>()
        allData.moveToFirst()
        var completeData = ""
        var col1 = allData.getString(allData.getColumnIndex("REGNO"))
        var col2 = allData.getString(allData.getColumnIndex("NAME"))
        var col3 = allData.getFloat(allData.getColumnIndex("CGPA"))
        var col4 = allData.getInt(allData.getColumnIndex("AGE"))
        var col5 = allData.getInt(allData.getColumnIndex("SUBJECTS"))
        var col6 = allData.getString(allData.getColumnIndex("ADDRESS"))

        completeData = "Record No. ${x + 1} \nRegNo: $col1 \nName: $col2 \n" +
                "CGPA: $col3\n" +
                "Age: $col4\n" +
                "Subjects: $col5\n" +
                "Address: $col6\n"
        db.close()

        val alertMessage: AlertDialog.Builder = AlertDialog.Builder(MainActivity@ view)
        alertMessage.setTitle("Do you want to Delete Record!!!")
        alertMessage.setMessage("$completeData")

        alertMessage.setPositiveButton("Delete", { a, b ->
            db = writableDatabase
            var Arg = arrayOf(pattern.toUpperCase())
            db.delete(tableName, "REGNO=?", Arg)
        })

        alertMessage.setNeutralButton("Cancel", { id, d ->
            //Toast.makeText(MainActivity@ this, "You pressed done button", Toast.LENGTH_SHORT).show()
        })

        alertMessage.create()
        alertMessage.show()
    }

    fun getPatternData(pattern: String):List<String>
    {
        var db = readableDatabase
        var readQuery = "Select * from $tableName where NAME like '%$pattern%' or UPPER(REGNO) = UPPER('$pattern')"
        var allData: Cursor = db.rawQuery(readQuery, null)
        var size = allData.count

        var x = 0
        var Data = listOf<String>()
        allData.moveToFirst()
        var completeData = ""
        while (x < size) {
            var col1 = allData.getString(allData.getColumnIndex("REGNO"))
            var col2 = allData.getString(allData.getColumnIndex("NAME"))
            var col3 = allData.getFloat(allData.getColumnIndex("CGPA"))
            var col4 = allData.getInt(allData.getColumnIndex("AGE"))
            var col5 = allData.getInt(allData.getColumnIndex("SUBJECTS"))
            var col6 = allData.getString(allData.getColumnIndex("ADDRESS"))

            completeData = "Record No. ${x + 1} \nRegNo: $col1 \nName: $col2 \n" +
                    "CGPA: $col3\n" +
                    "Age: $col4\n" +
                    "Subjects: $col5\n" +
                    "Address: $col6\n"

            Data += completeData
            allData.moveToNext()
            x++

        }
        return Data
    }

}