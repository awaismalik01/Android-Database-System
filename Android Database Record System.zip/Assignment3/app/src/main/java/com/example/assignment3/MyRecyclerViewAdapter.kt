package com.example.assignment3

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class MyRecyclerViewAdatper(var context:Context, var dList: List<String>
                            ) : RecyclerView.Adapter<MyRecyclerViewAdatper.viewHolder>()
{

    class viewHolder(itemView: View): RecyclerView.ViewHolder(itemView)
    {
        var imageView:ImageView = itemView.findViewById(R.id.imageView)
        //var Record:TextView = itemView.findViewById(R.id.Record)
        var Data:TextView = itemView.findViewById(R.id.Details)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): viewHolder {
//        TODO("Not yet implemented")
        var myView = LayoutInflater.from(context).inflate(R.layout.activity_my_recycler_view_adapter, parent, false)
        return viewHolder(myView)
    }

    override fun onBindViewHolder(holder: viewHolder, position: Int) {
//        TODO("Not yet implemented")
        //holder.Record.setText(rList.get(position).toString())
        holder.Data.setText(dList.get(position))

        holder.Data.setOnClickListener({

        })
    }

    override fun getItemCount(): Int {
//        TODO("Not yet implemented")
        return dList.size
    }
}